package com.neo.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.neo.security.entity.LocalService;

public interface LocalServiceRepository extends JpaRepository<LocalService, Integer>{

}
